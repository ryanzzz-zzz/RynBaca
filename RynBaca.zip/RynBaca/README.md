# Ryn Baca 1.0

Aplikasi Android latihan membaca untuk anak kelas 5 SD.
Kotlin + Jetpack Compose. Offline penuh, tanpa login, tanpa internet.

## Cara menjalankan
1. Pasang **Android Studio** (versi terbaru, gratis).
2. Ekstrak zip ini, lalu di Android Studio pilih **File > Open** dan pilih folder `RynBaca`.
3. Tunggu "Gradle Sync" selesai (butuh internet, hanya saat pertama kali).
4. Sambungkan HP (aktifkan USB debugging) atau buat emulator, lalu klik tombol hijau **Run ▶**.

## Cara build APK
- Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- Setelah selesai klik **locate**. File ada di:
  - `app/build/outputs/apk/debug/app-debug.apk`
- Kirim file APK itu ke HP, buka, dan pasang (izinkan "pasang dari sumber tidak dikenal").
- APK yang lebih kecil: pilih **Build > Select Build Variant > release**, lalu Build APK.
  Hasil: `app/build/outputs/apk/release/app-release.apk`.

## Struktur folder (app/src/main/java/com/ryn/baca)
- `config/GameConfig.kt` : semua angka XP, level, target harian
- `model/Models.kt` : Word, Sentence, Story, Question
- `data/` : materi (WordData, SentenceData, StoryData, ContentRepository)
- `progress/` : hitung XP, streak, WPM (ProgressManager, ProgressCalc, ProgressState)
- `storage/ProgressStore.kt` : simpan data di HP
- `achievement/Achievements.kt` : daftar pencapaian
- `audio/Speaker.kt` : Text-to-Speech bahasa Indonesia
- `latihan/` : layar Latihan Kata, Suku Kata, Kalimat, Cerita
- `ui/` : Beranda, Belajar, Progress, Profil, tema, komponen

## Mengganti materi bacaan
- **Kata**: buka `data/WordData.kt`, tambah baris `kata|su-ku-ka-ta` di daftar MUDAH / MEDIUM / HARD.
- **Kalimat**: buka `data/SentenceData.kt`, tambah satu kalimat per baris.

## Menambah cerita
Buka `data/StoryData.kt`, salin satu blok `Story(...)` ke dalam `listOf(...)`, lalu ubah:
`id` (harus unik, misal "c11"), `title`, `difficulty`, `content`, dan `questions`.
Setiap `Question` berisi teks, daftar pilihan, dan nomor jawaban benar (mulai dari 0 = A).

## Mengubah jumlah XP
Buka `config/GameConfig.kt`. Ubah `XP_WORD`, `XP_SENTENCE`, `XP_STORY`,
`XP_CORRECT_ANSWER`, `XP_DAILY_TARGET`, `XP_PER_LEVEL`, dan `DAILY_TARGET_MINUTES`.

## Mengubah warna / tampilan
Buka `ui/theme/Theme.kt`, ubah nilai warna di `RynColors`.
Warna ikon aplikasi: `app/src/main/res/values/colors.xml`.
Nama aplikasi: `app/src/main/res/values/strings.xml`.

## Catatan
- Minimal Android 8.0 (API 26).
- Jika Text-to-Speech Indonesia belum ada, pasang "Speech Services by Google" dan unduh suara Bahasa Indonesia.
  Tanpa suara, aplikasi tetap berjalan normal.
