package com.ryn.baca.latihan

/** Jenis latihan yang bisa dibuka dari menu. */
enum class Latihan { KATA, SUKU_KATA, KALIMAT, CERITA }
