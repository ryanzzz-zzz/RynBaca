package com.ryn.baca.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.MainViewModel
import com.ryn.baca.achievement.Achievements
import com.ryn.baca.config.GameConfig
import com.ryn.baca.progress.ProgressCalc
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.components.ScreenHeader
import com.ryn.baca.ui.components.StatTile
import com.ryn.baca.ui.theme.RynColors
import java.time.DayOfWeek
import java.time.LocalDate

@Composable
fun ProgressScreen(vm: MainViewModel) {
    val s = vm.progress.state
    val streak = ProgressCalc.currentStreak(s)
    val avg = ProgressCalc.averageWpm(s)
    val acc = ProgressCalc.accuracy(s)
    val points = ProgressCalc.wpmByDay(s)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader("Perkembangan Membaca")

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("🔥", "Streak", "$streak hari", Modifier.weight(1f))
            StatTile("📚", "Total latihan", "${s.totalPractices}", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("⏱️", "Total waktu membaca", ProgressCalc.formatDuration(s.totalReadingSeconds), Modifier.weight(1f))
            StatTile("⚡", "Rata-rata WPM", avg?.toString() ?: "-", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("🎯", "Akurasi pertanyaan", if (acc != null) "$acc%" else "-", Modifier.weight(1f))
            StatTile("⭐", "XP", "${s.xp}", Modifier.weight(1f))
        }

        Text("Grafik Kecepatan (WPM)", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        RynCard(Modifier.fillMaxWidth()) {
            if (points.size >= GameConfig.MIN_CHART_POINTS) {
                WpmChart(points)
            } else {
                Text(
                    "Grafik akan muncul setelah kamu berlatih membaca kalimat atau cerita beberapa hari. Teruskan! 💪",
                    fontSize = 15.sp,
                    color = RynColors.TextMuted
                )
            }
        }

        Text("Pencapaian", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Achievements.all.forEach { a ->
            val unlocked = a.id in s.achievements
            RynCard(
                Modifier.fillMaxWidth(),
                containerColor = if (unlocked) RynColors.AccentLight else RynColors.Card
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (unlocked) a.emoji else "🔒", fontSize = 30.sp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(
                            a.title,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (unlocked) RynColors.TextDark else RynColors.TextMuted
                        )
                        Text(a.description, fontSize = 13.sp, color = RynColors.TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
private fun WpmChart(points: List<Pair<String, Int>>) {
    val values = points.map { it.second }
    val minV = values.min().toFloat()
    val maxV = values.max().toFloat()
    val range = if (maxV - minV < 1f) 1f else maxV - minV
    val lineColor = RynColors.Primary
    val n = values.size

    Column {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            fun px(i: Int) = size.width * (i + 0.5f) / n
            fun py(v: Int) = size.height * 0.1f + size.height * 0.8f * (1f - (v - minV) / range)
            for (i in 0 until n - 1) {
                drawLine(
                    color = lineColor,
                    start = Offset(px(i), py(values[i])),
                    end = Offset(px(i + 1), py(values[i + 1])),
                    strokeWidth = 6f,
                    cap = StrokeCap.Round
                )
            }
            for (i in 0 until n) {
                drawCircle(color = lineColor, radius = 11f, center = Offset(px(i), py(values[i])))
            }
        }
        Row(Modifier.fillMaxWidth()) {
            points.forEach { (date, wpm) ->
                Text(
                    "${dayLabel(date)}\n$wpm",
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontSize = 12.sp,
                    color = RynColors.TextMuted
                )
            }
        }
    }
}

private fun dayLabel(date: String): String = try {
    when (LocalDate.parse(date).dayOfWeek) {
        DayOfWeek.MONDAY -> "Sen"
        DayOfWeek.TUESDAY -> "Sel"
        DayOfWeek.WEDNESDAY -> "Rab"
        DayOfWeek.THURSDAY -> "Kam"
        DayOfWeek.FRIDAY -> "Jum"
        DayOfWeek.SATURDAY -> "Sab"
        DayOfWeek.SUNDAY -> "Min"
    }
} catch (e: Exception) {
    ""
}
