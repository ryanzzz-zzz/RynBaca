package com.ryn.baca.latihan

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.MainViewModel
import com.ryn.baca.config.GameConfig
import com.ryn.baca.data.ContentRepository
import com.ryn.baca.model.Difficulty
import com.ryn.baca.model.WordRating
import com.ryn.baca.ui.components.AnimatedProgressBar
import com.ryn.baca.ui.components.BigButton
import com.ryn.baca.ui.components.DifficultyPicker
import com.ryn.baca.ui.components.RoundSummary
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.components.ScreenHeader
import com.ryn.baca.ui.components.SoftButton
import com.ryn.baca.ui.components.wordFontSize
import com.ryn.baca.ui.theme.RynColors

@Composable
fun WordPracticeScreen(vm: MainViewModel, onExit: () -> Unit) {
    var difficulty by remember { mutableStateOf<Difficulty?>(null) }
    var round by remember { mutableIntStateOf(0) }
    val chosen = difficulty
    if (chosen == null) {
        DifficultyPicker(
            title = "Latihan Kata",
            subtitle = "Pilih tingkat kata yang ingin kamu baca.",
            onBack = onExit,
            onPick = { difficulty = it }
        )
    } else {
        key(round) {
            WordRound(vm, chosen, onAgain = { round += 1 }, onExit = onExit)
        }
    }
}

@Composable
private fun WordRound(vm: MainViewModel, difficulty: Difficulty, onAgain: () -> Unit, onExit: () -> Unit) {
    val context = LocalContext.current
    val words = remember {
        ContentRepository.wordsBy(difficulty).shuffled().take(GameConfig.WORDS_PER_ROUND)
    }
    var index by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    var earnedXp by remember { mutableIntStateOf(0) }
    var shownAt by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }

    if (index >= words.size) {
        RoundSummary(
            title = "Hebat!",
            message = "Kamu sudah membaca ${words.size} kata.",
            xp = earnedXp,
            onAgain = onAgain,
            onExit = onExit
        )
    } else {
        val word = words[index]
        val rate = { rating: WordRating ->
            val secs = ((SystemClock.elapsedRealtime() - shownAt) / 1000).toInt()
            val reward = vm.progress.recordWord(word, rating, secs)
            earnedXp += reward.xp
            revealed = false
            index += 1
            shownAt = SystemClock.elapsedRealtime()
        }
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ScreenHeader("Latihan Kata", onExit)
            Text("Kata ${index + 1} dari ${words.size}", fontSize = 14.sp, color = RynColors.TextMuted)
            AnimatedProgressBar(index.toFloat() / words.size)

            RynCard(Modifier.fillMaxWidth()) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        word.word.uppercase(),
                        fontSize = wordFontSize(word.word.length),
                        fontWeight = FontWeight.ExtraBold,
                        color = RynColors.Primary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            SoftButton("🔊 Dengarkan", { vm.speaker.speakOrNotify(context, word.word) }, Modifier.fillMaxWidth())

            if (!revealed) {
                BigButton("Saya Sudah Membaca ✓", { revealed = true }, Modifier.fillMaxWidth(), RynColors.Success)
            } else {
                Text(
                    "Bagaimana rasanya membaca kata ini?",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = RynColors.TextDark
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigButton("Mudah", { rate(WordRating.MUDAH) }, Modifier.weight(1f), RynColors.Success)
                    BigButton("Lumayan", { rate(WordRating.LUMAYAN) }, Modifier.weight(1f), RynColors.Warning)
                    BigButton("Sulit", { rate(WordRating.SULIT) }, Modifier.weight(1f), RynColors.Danger)
                }
            }
        }
    }
}
