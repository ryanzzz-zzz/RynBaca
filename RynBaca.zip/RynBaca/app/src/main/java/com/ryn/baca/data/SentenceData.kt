package com.ryn.baca.data

import com.ryn.baca.model.Difficulty
import com.ryn.baca.model.Sentence

/** Daftar kalimat. Satu kalimat per baris. Tambah baris baru untuk menambah materi. */
object SentenceData {

    private val EASY = """
Budi pergi ke sekolah pagi ini.
Ibu memasak nasi di dapur.
Ayah membaca koran di teras.
Adik bermain bola di halaman.
Kucing itu tidur di atas kursi.
Aku minum susu setiap pagi.
Kakak membeli buku di toko.
Nenek menanam bunga di kebun.
"""

    private val MEDIUM = """
Setelah pulang sekolah, Rini membantu ibu menyapu halaman rumah.
Matahari bersinar terang sehingga jemuran cepat kering.
Kami berjalan kaki ke perpustakaan untuk meminjam buku cerita.
Pak Guru menjelaskan pelajaran dengan sabar di depan kelas.
Setiap Minggu pagi, keluarga kami berolahraga di lapangan dekat rumah.
Burung-burung berterbangan di langit yang biru dan cerah.
Dodi selalu merapikan tempat tidurnya sebelum berangkat sekolah.
Hujan deras membuat jalan di depan sekolah menjadi licin.
"""

    private val HARD = """
Kita harus menjaga kebersihan lingkungan agar semua orang hidup sehat dan nyaman.
Persahabatan yang tulus membuat kita saling membantu dalam suka maupun duka.
Anak yang bertanggung jawab akan menyelesaikan tugasnya tanpa disuruh.
Perpustakaan sekolah menyediakan banyak buku yang menambah pengetahuan kita.
Dengan rajin membaca setiap hari, kemampuan membaca kita akan semakin lancar.
Para petani bekerja keras di sawah sejak matahari terbit hingga sore hari.
Walaupun hujan turun deras, murid-murid tetap datang ke sekolah dengan semangat.
Kejujuran adalah sifat terpuji yang harus kita latih sejak kecil.
"""

    private fun parse(raw: String, d: Difficulty, prefix: String): List<Sentence> =
        raw.lines().map { it.trim() }.filter { it.isNotEmpty() }.mapIndexed { i, line ->
            Sentence(id = "$prefix${i + 1}", text = line, difficulty = d)
        }

    fun build(): List<Sentence> =
        parse(EASY, Difficulty.MUDAH, "km") +
            parse(MEDIUM, Difficulty.SEDANG, "ks") +
            parse(HARD, Difficulty.SULIT, "kh")
}
