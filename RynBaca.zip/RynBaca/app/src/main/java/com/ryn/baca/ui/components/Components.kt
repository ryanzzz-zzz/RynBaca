package com.ryn.baca.ui.components

import android.os.SystemClock
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.achievement.Achievement
import com.ryn.baca.model.Difficulty
import com.ryn.baca.ui.theme.RynColors
import kotlinx.coroutines.delay

@Composable
fun BigButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = RynColors.Primary,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(60.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color)
    ) {
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(18.dp)
    ) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = RynColors.Primary)
    }
}

@Composable
fun RynCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    containerColor: Color = RynColors.Card,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    val base = if (onClick != null) modifier.clip(shape).clickable(onClick = onClick) else modifier
    Card(
        modifier = base,
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun AnimatedProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    color: Color = RynColors.Primary,
    height: Int = 14
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(600),
        label = "bar"
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(height.dp)
            .clip(RoundedCornerShape(50))
            .background(RynColors.Track)
    ) {
        Box(
            Modifier
                .fillMaxWidth(animated)
                .fillMaxHeight()
                .clip(RoundedCornerShape(50))
                .background(color)
        )
    }
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null) {
    Column {
        if (onBack != null) {
            TextButton(onClick = onBack) {
                Text("← Kembali", fontSize = 16.sp, color = RynColors.Primary)
            }
        }
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = RynColors.TextDark)
    }
}

@Composable
fun StatTile(emoji: String, label: String, value: String, modifier: Modifier = Modifier) {
    RynCard(modifier = modifier) {
        Text(emoji, fontSize = 26.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RynColors.TextDark)
        Text(label, fontSize = 13.sp, color = RynColors.TextMuted)
    }
}

@Composable
fun Pill(text: String, background: Color, foreground: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = foreground)
    }
}

/** Layar pilih tingkat kesulitan (dipakai Latihan Kata, Suku Kata, Kalimat). */
@Composable
fun DifficultyPicker(
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    onPick: (Difficulty) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader(title, onBack)
        Text(subtitle, fontSize = 16.sp, color = RynColors.TextMuted)
        Difficulty.values().forEach { d ->
            RynCard(modifier = Modifier.fillMaxWidth(), onClick = { onPick(d) }) {
                Text("${d.emoji}  ${d.label}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(d.hint, fontSize = 14.sp, color = RynColors.TextMuted)
            }
        }
    }
}

/** Ringkasan di akhir satu putaran latihan, dengan animasi XP. */
@Composable
fun RoundSummary(
    title: String,
    message: String,
    xp: Int,
    onAgain: () -> Unit,
    onExit: () -> Unit,
    againText: String = "Main Lagi"
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val scale by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "pop"
    )
    val shownXp by animateIntAsState(
        targetValue = if (shown) xp else 0,
        animationSpec = tween(900),
        label = "xp"
    )
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🎉", fontSize = 72.sp, modifier = Modifier.scale(scale))
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = RynColors.TextDark)
        Text(message, fontSize = 17.sp, color = RynColors.TextMuted, textAlign = TextAlign.Center)
        Text(
            "+$shownXp XP",
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold,
            color = RynColors.Accent,
            modifier = Modifier.scale(scale)
        )
        Spacer(Modifier.height(8.dp))
        BigButton(againText, onAgain, Modifier.fillMaxWidth())
        SoftButton("Selesai", onExit, Modifier.fillMaxWidth())
    }
}

@Composable
fun AchievementDialog(achievement: Achievement, onDismiss: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val scale by animateFloatAsState(
        targetValue = if (shown) 1f else 0.3f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "badge"
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Hebat!", fontSize = 18.sp) } },
        title = { Text("Pencapaian Baru! 🎉", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(achievement.emoji, fontSize = 64.sp, modifier = Modifier.scale(scale))
                Text(achievement.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(achievement.description, fontSize = 15.sp, color = RynColors.TextMuted, textAlign = TextAlign.Center)
            }
        }
    )
}

/** Stopwatch sederhana: mengembalikan detik yang sudah berjalan sejak startMs. */
@Composable
fun rememberElapsedSeconds(running: Boolean, startMs: Long): Int {
    val elapsed = remember { mutableIntStateOf(0) }
    LaunchedEffect(running, startMs) {
        while (running) {
            elapsed.intValue = ((SystemClock.elapsedRealtime() - startMs) / 1000).toInt()
            delay(250)
        }
    }
    return elapsed.intValue
}

fun wordFontSize(length: Int) = when {
    length > 12 -> 34.sp
    length > 9 -> 42.sp
    else -> 52.sp
}
