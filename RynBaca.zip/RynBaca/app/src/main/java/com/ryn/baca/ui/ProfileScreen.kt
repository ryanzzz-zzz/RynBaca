package com.ryn.baca.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.MainViewModel
import com.ryn.baca.config.GameConfig
import com.ryn.baca.progress.ProgressCalc
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.components.ScreenHeader
import com.ryn.baca.ui.components.SoftButton
import com.ryn.baca.ui.theme.RynColors

@Composable
fun ProfileScreen(vm: MainViewModel) {
    val s = vm.progress.state
    val streak = ProgressCalc.currentStreak(s)
    val avg = ProgressCalc.averageWpm(s)
    val acc = ProgressCalc.accuracy(s)
    var name by remember { mutableStateOf(s.childName) }
    var confirmReset by remember { mutableStateOf(false) }
    val hardList = s.hardWords.entries.sortedByDescending { it.value }.take(10)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader("Profil")

        RynCard(Modifier.fillMaxWidth()) {
            Text("Level ${GameConfig.levelForXp(s.xp)} • ${s.xp} XP", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = RynColors.Primary)
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it.take(20)
                    vm.progress.setName(name)
                },
                label = { Text("Nama") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
            )
        }

        Text("Untuk Orang Tua", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        RynCard(Modifier.fillMaxWidth()) {
            Text("Progress Saya", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            InfoRow("Total latihan", "${s.totalPractices}")
            InfoRow("Total waktu", ProgressCalc.formatDuration(s.totalReadingSeconds))
            InfoRow("Rata-rata WPM", avg?.toString() ?: "-")
            InfoRow("Akurasi", if (acc != null) "$acc%" else "-")
            InfoRow("Streak", "$streak hari")
            InfoRow("Cerita selesai", "${s.completedStories.size}")
        }

        RynCard(Modifier.fillMaxWidth()) {
            Text("Kata yang Sering Sulit", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            if (hardList.isEmpty()) {
                Text(
                    "Belum ada. Kata yang dipilih \"Sulit\" saat Latihan Kata akan muncul di sini.",
                    fontSize = 14.sp,
                    color = RynColors.TextMuted,
                    modifier = Modifier.padding(top = 6.dp)
                )
            } else {
                hardList.forEach { (word, count) ->
                    InfoRow(word, "${count}x")
                }
            }
        }

        SoftButton("Hapus Semua Data", { confirmReset = true }, Modifier.fillMaxWidth())
        Text("Ryn Baca versi 1.0", fontSize = 12.sp, color = RynColors.TextMuted)
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Hapus semua data?") },
            text = { Text("XP, level, streak, dan semua catatan latihan akan dihapus dari HP ini.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.progress.resetAll()
                    name = ""
                    confirmReset = false
                }) { Text("Hapus", color = RynColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 15.sp, color = RynColors.TextMuted)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = RynColors.TextDark)
    }
}
