package com.ryn.baca.achievement

import com.ryn.baca.progress.ProgressState

class Achievement(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val isUnlocked: (ProgressState) -> Boolean
)

/** Daftar pencapaian. Terbuka otomatis berdasarkan progress. */
object Achievements {
    val all: List<Achievement> = listOf(
        Achievement("first", "🏆", "Pembaca Pertama", "Melakukan latihan pertama") {
            it.totalPractices >= 1
        },
        Achievement("streak3", "🔥", "3 Hari Berturut-turut", "Belajar selama 3 hari berturut-turut") {
            it.streak >= 3
        },
        Achievement("stories10", "📚", "10 Cerita", "Menyelesaikan 10 cerita") {
            it.completedStories.size >= 10
        },
        Achievement("wpm50", "⚡", "50 WPM", "Mencapai 50 kata per menit") { s ->
            s.sessions.any { it.words >= 8 && it.wpm >= 50 }
        },
        Achievement("correct10", "🎯", "10 Jawaban Benar", "Menjawab 10 pertanyaan dengan benar") {
            it.correctAnswers >= 10
        },
        Achievement("words50", "🔤", "50 Kata", "Membaca 50 kata dalam latihan kata") {
            it.wordsDone >= 50
        }
    )

    fun newlyUnlocked(s: ProgressState): List<Achievement> =
        all.filter { it.id !in s.achievements && it.isUnlocked(s) }
}
