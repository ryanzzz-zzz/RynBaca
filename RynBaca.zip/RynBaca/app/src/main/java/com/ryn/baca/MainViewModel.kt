package com.ryn.baca

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.ryn.baca.audio.Speaker
import com.ryn.baca.progress.ProgressManager
import com.ryn.baca.storage.ProgressStore

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val progress = ProgressManager(ProgressStore(app))
    val speaker = Speaker(app)

    override fun onCleared() {
        speaker.shutdown()
    }
}
