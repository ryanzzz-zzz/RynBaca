package com.ryn.baca.data

import com.ryn.baca.model.Difficulty
import com.ryn.baca.model.Sentence
import com.ryn.baca.model.Story
import com.ryn.baca.model.Word

/** Pintu tunggal untuk semua materi bacaan (kata, kalimat, cerita). */
object ContentRepository {
    val words: List<Word> by lazy { WordData.build() }
    val sentences: List<Sentence> by lazy { SentenceData.build() }
    val stories: List<Story> by lazy { StoryData.build() }

    fun wordsBy(d: Difficulty): List<Word> = words.filter { it.difficulty == d }
    fun sentencesBy(d: Difficulty): List<Sentence> = sentences.filter { it.difficulty == d }
}
