package com.ryn.baca

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ryn.baca.ui.AppRoot
import com.ryn.baca.ui.theme.RynBacaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RynBacaTheme {
                AppRoot()
            }
        }
    }
}
