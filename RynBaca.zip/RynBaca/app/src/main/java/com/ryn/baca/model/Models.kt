package com.ryn.baca.model

enum class Difficulty(val label: String, val emoji: String, val hint: String) {
    MUDAH("Mudah", "🟢", "Mulai dari yang ringan"),
    SEDANG("Sedang", "🟡", "Sudah agak menantang"),
    SULIT("Sulit", "🔴", "Untuk pembaca berani")
}

/** Penilaian anak setelah membaca sebuah kata. */
enum class WordRating { MUDAH, LUMAYAN, SULIT }

data class Word(
    val id: String,
    val word: String,
    val syllables: List<String>,
    val difficulty: Difficulty
)

data class Sentence(
    val id: String,
    val text: String,
    val difficulty: Difficulty
)

data class Question(
    val text: String,
    val options: List<String>,
    val answerIndex: Int
)

data class Story(
    val id: String,
    val title: String,
    val content: String,
    val questions: List<Question>,
    val difficulty: Difficulty
)

fun countWords(text: String): Int =
    text.trim().split(Regex("\\s+")).count { it.isNotBlank() }
