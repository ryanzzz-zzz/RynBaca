package com.ryn.baca.config

/**
 * SEMUA angka permainan ada di file ini.
 * Ubah angka di sini untuk mengatur XP, level, target harian, dan jumlah soal per putaran.
 */
object GameConfig {
    const val TAGLINE = "Sedikit membaca setiap hari, makin lancar setiap hari."

    // XP yang didapat
    const val XP_WORD = 10            // latihan kata (per kata)
    const val XP_SYLLABLE = 10        // latihan suku kata (per kata)
    const val XP_SENTENCE = 20        // latihan kalimat (per kalimat)
    const val XP_STORY = 30           // menyelesaikan cerita
    const val XP_CORRECT_ANSWER = 10  // jawaban benar (percobaan pertama)
    const val XP_DAILY_TARGET = 20    // bonus saat target harian tercapai

    // Target membaca harian (menit)
    const val DAILY_TARGET_MINUTES = 10

    // Level: setiap XP_PER_LEVEL XP naik satu level.
    // Level 1 = 0 XP, Level 2 = 500 XP, Level 3 = 1.000 XP, dst.
    const val XP_PER_LEVEL = 500

    // Jumlah soal tiap putaran latihan
    const val WORDS_PER_ROUND = 10
    const val SENTENCES_PER_ROUND = 5

    // Grafik WPM baru muncul jika ada minimal sekian hari data
    const val MIN_CHART_POINTS = 3

    // Batas waktu (detik) yang dihitung untuk satu kata
    const val MAX_WORD_SECONDS = 30

    fun levelForXp(xp: Int): Int = xp / XP_PER_LEVEL + 1
    fun xpIntoLevel(xp: Int): Int = xp % XP_PER_LEVEL
}
