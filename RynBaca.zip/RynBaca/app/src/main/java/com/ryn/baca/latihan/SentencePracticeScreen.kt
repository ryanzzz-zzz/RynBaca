package com.ryn.baca.latihan

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.MainViewModel
import com.ryn.baca.config.GameConfig
import com.ryn.baca.data.ContentRepository
import com.ryn.baca.model.Difficulty
import com.ryn.baca.model.countWords
import com.ryn.baca.progress.ProgressCalc
import com.ryn.baca.ui.components.AnimatedProgressBar
import com.ryn.baca.ui.components.BigButton
import com.ryn.baca.ui.components.DifficultyPicker
import com.ryn.baca.ui.components.RoundSummary
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.components.ScreenHeader
import com.ryn.baca.ui.components.SoftButton
import com.ryn.baca.ui.components.rememberElapsedSeconds
import com.ryn.baca.ui.theme.RynColors
import kotlin.math.roundToInt

private enum class SentencePhase { READY, READING, DONE }

@Composable
fun SentencePracticeScreen(vm: MainViewModel, onExit: () -> Unit) {
    var difficulty by remember { mutableStateOf<Difficulty?>(null) }
    var round by remember { mutableIntStateOf(0) }
    val chosen = difficulty
    if (chosen == null) {
        DifficultyPicker(
            title = "Latihan Kalimat",
            subtitle = "Baca kalimat dengan suara pelan atau dalam hati.",
            onBack = onExit,
            onPick = { difficulty = it }
        )
    } else {
        key(round) {
            SentenceRound(vm, chosen, onAgain = { round += 1 }, onExit = onExit)
        }
    }
}

@Composable
private fun SentenceRound(vm: MainViewModel, difficulty: Difficulty, onAgain: () -> Unit, onExit: () -> Unit) {
    val context = LocalContext.current
    val sentences = remember {
        ContentRepository.sentencesBy(difficulty).shuffled().take(GameConfig.SENTENCES_PER_ROUND)
    }
    var index by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf(SentencePhase.READY) }
    var startMs by remember { mutableLongStateOf(0L) }
    var resultSeconds by remember { mutableIntStateOf(1) }
    var earnedXp by remember { mutableIntStateOf(0) }
    val elapsed = rememberElapsedSeconds(phase == SentencePhase.READING, startMs)

    if (index >= sentences.size) {
        RoundSummary(
            title = "Hebat!",
            message = "Kamu sudah membaca ${sentences.size} kalimat.",
            xp = earnedXp,
            onAgain = onAgain,
            onExit = onExit
        )
    } else {
        val sentence = sentences[index]
        val wordCount = countWords(sentence.text)
        val isLast = index == sentences.size - 1

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ScreenHeader("Latihan Kalimat", onExit)
            Text("Kalimat ${index + 1} dari ${sentences.size}", fontSize = 14.sp, color = RynColors.TextMuted)
            AnimatedProgressBar(index.toFloat() / sentences.size)

            RynCard(Modifier.fillMaxWidth()) {
                Text(
                    sentence.text,
                    fontSize = 28.sp,
                    lineHeight = 40.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = RynColors.TextDark,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    textAlign = TextAlign.Center
                )
            }

            when (phase) {
                SentencePhase.READY -> {
                    SoftButton("🔊 Dengarkan contoh", { vm.speaker.speakOrNotify(context, sentence.text) }, Modifier.fillMaxWidth())
                    BigButton(
                        "⏱️ Mulai membaca",
                        {
                            startMs = SystemClock.elapsedRealtime()
                            phase = SentencePhase.READING
                        },
                        Modifier.fillMaxWidth()
                    )
                }

                SentencePhase.READING -> {
                    Text(
                        "⏱️ ${ProgressCalc.formatClock(elapsed)}",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        color = RynColors.Primary,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                    BigButton(
                        "Saya sudah selesai ✓",
                        {
                            val secs = ((SystemClock.elapsedRealtime() - startMs) / 1000).toInt().coerceAtLeast(1)
                            resultSeconds = secs
                            val reward = vm.progress.recordSentence(sentence, secs)
                            earnedXp += reward.xp
                            phase = SentencePhase.DONE
                        },
                        Modifier.fillMaxWidth(),
                        RynColors.Success
                    )
                }

                SentencePhase.DONE -> {
                    val wpm = (wordCount * 60f / resultSeconds).roundToInt()
                    RynCard(Modifier.fillMaxWidth(), containerColor = RynColors.SuccessLight) {
                        Text("Bagus! 🎉  +${GameConfig.XP_SENTENCE} XP", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = RynColors.Success)
                        Text("⏱️ Waktu: $resultSeconds detik", fontSize = 16.sp)
                        Text("📝 Jumlah kata: $wordCount", fontSize = 16.sp)
                        Text("⚡ Perkiraan: $wpm kata per menit", fontSize = 16.sp)
                        Text(
                            "Ini hanya catatan perkembanganmu, bukan nilai.",
                            fontSize = 13.sp,
                            color = RynColors.TextMuted
                        )
                    }
                    BigButton(
                        if (isLast) "Selesai" else "Berikutnya",
                        {
                            index += 1
                            phase = SentencePhase.READY
                        },
                        Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
