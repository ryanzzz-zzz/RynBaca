package com.ryn.baca.latihan

import android.os.SystemClock
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.MainViewModel
import com.ryn.baca.config.GameConfig
import com.ryn.baca.data.ContentRepository
import com.ryn.baca.model.Difficulty
import com.ryn.baca.ui.components.AnimatedProgressBar
import com.ryn.baca.ui.components.BigButton
import com.ryn.baca.ui.components.DifficultyPicker
import com.ryn.baca.ui.components.RoundSummary
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.components.ScreenHeader
import com.ryn.baca.ui.components.SoftButton
import com.ryn.baca.ui.theme.RynColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SyllablePracticeScreen(vm: MainViewModel, onExit: () -> Unit) {
    var difficulty by remember { mutableStateOf<Difficulty?>(null) }
    var round by remember { mutableIntStateOf(0) }
    val chosen = difficulty
    if (chosen == null) {
        DifficultyPicker(
            title = "Latihan Suku Kata",
            subtitle = "Lihat suku kata, lalu gabungkan menjadi satu kata.",
            onBack = onExit,
            onPick = { difficulty = it }
        )
    } else {
        key(round) {
            SyllableRound(vm, chosen, onAgain = { round += 1 }, onExit = onExit)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SyllableRound(vm: MainViewModel, difficulty: Difficulty, onAgain: () -> Unit, onExit: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val words = remember {
        ContentRepository.wordsBy(difficulty)
            .filter { it.syllables.size >= 2 }
            .shuffled()
            .take(GameConfig.WORDS_PER_ROUND)
    }
    var index by remember { mutableIntStateOf(0) }
    var highlight by remember { mutableIntStateOf(-1) }
    var joined by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var earnedXp by remember { mutableIntStateOf(0) }
    var shownAt by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }

    if (index >= words.size) {
        RoundSummary(
            title = "Bagus!",
            message = "Kamu sudah menggabungkan ${words.size} kata.",
            xp = earnedXp,
            onAgain = onAgain,
            onExit = onExit
        )
    } else {
        val word = words[index]
        val play = {
            if (!playing) {
                if (!vm.speaker.available) {
                    Toast.makeText(context, "Suara belum tersedia, tapi kamu tetap bisa berlatih 😊", Toast.LENGTH_SHORT).show()
                }
                playing = true
                joined = false
                scope.launch {
                    for (i in word.syllables.indices) {
                        highlight = i
                        vm.speaker.speak(word.syllables[i])
                        delay(850)
                    }
                    highlight = -1
                    joined = true
                    vm.speaker.speak(word.word)
                    playing = false
                }
                Unit
            }
        }
        val next = {
            val secs = ((SystemClock.elapsedRealtime() - shownAt) / 1000).toInt()
            val reward = vm.progress.recordSyllable(secs)
            earnedXp += reward.xp
            joined = false
            highlight = -1
            index += 1
            shownAt = SystemClock.elapsedRealtime()
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ScreenHeader("Latihan Suku Kata", onExit)
            Text("Kata ${index + 1} dari ${words.size}", fontSize = 14.sp, color = RynColors.TextMuted)
            AnimatedProgressBar(index.toFloat() / words.size)

            RynCard(Modifier.fillMaxWidth()) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            word.syllables.forEachIndexed { i, syl ->
                                if (i > 0) {
                                    Text("+", fontSize = 26.sp, color = RynColors.TextMuted, modifier = Modifier.padding(top = 10.dp))
                                }
                                SyllableChip(syl.uppercase(), active = highlight == i)
                            }
                        }
                        AnimatedVisibility(visible = joined) {
                            Text(
                                word.word.uppercase(),
                                fontSize = 38.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = RynColors.Success,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            if (!joined) {
                BigButton(
                    if (playing) "Membaca..." else "▶ Baca Suku Kata",
                    { play() },
                    Modifier.fillMaxWidth(),
                    enabled = !playing
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SoftButton("Ulangi ▶", { play() }, Modifier.weight(1f))
                    BigButton("Berikutnya", { next() }, Modifier.weight(1f), RynColors.Success)
                }
            }
        }
    }
}

@Composable
private fun SyllableChip(text: String, active: Boolean) {
    val scale by animateFloatAsState(if (active) 1.25f else 1f, tween(250), label = "chipScale")
    val bg by animateColorAsState(
        if (active) RynColors.Accent else RynColors.PrimaryLight,
        tween(250),
        label = "chipColor"
    )
    Box(
        Modifier
            .scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            text,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) androidx.compose.ui.graphics.Color.White else RynColors.Primary
        )
    }
}
