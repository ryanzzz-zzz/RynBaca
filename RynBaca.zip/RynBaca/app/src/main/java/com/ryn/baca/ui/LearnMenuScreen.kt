package com.ryn.baca.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.latihan.Latihan
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.components.ScreenHeader
import com.ryn.baca.ui.theme.RynColors

@Composable
fun LearnMenuScreen(onOpen: (Latihan) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader("Belajar")
        Text("Pilih latihan yang ingin kamu coba hari ini.", fontSize = 15.sp, color = RynColors.TextMuted)
        MenuCard("🔤", "Latihan Kata", "Baca kata satu per satu", Latihan.KATA, onOpen)
        MenuCard("🧩", "Latihan Suku Kata", "Gabungkan suku kata jadi kata", Latihan.SUKU_KATA, onOpen)
        MenuCard("📖", "Latihan Kalimat", "Baca kalimat dan lihat kecepatanmu", Latihan.KALIMAT, onOpen)
        MenuCard("📚", "Cerita Pendek", "Baca cerita, lalu jawab pertanyaan", Latihan.CERITA, onOpen)
    }
}

@Composable
private fun MenuCard(
    emoji: String,
    title: String,
    subtitle: String,
    target: Latihan,
    onOpen: (Latihan) -> Unit
) {
    RynCard(Modifier.fillMaxWidth(), onClick = { onOpen(target) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 36.sp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, fontSize = 14.sp, color = RynColors.TextMuted)
            }
        }
    }
}
