package com.ryn.baca.progress

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

/** Fungsi hitung-hitungan (streak, waktu, WPM, akurasi). */
object ProgressCalc {

    /** Tanggal lokal perangkat, contoh "2026-09-30". */
    fun todayKey(): String = LocalDate.now().toString()

    /** Streak yang ditampilkan: kembali 0 jika kemarin tidak berlatih. */
    fun currentStreak(s: ProgressState, day: String = todayKey()): Int {
        if (s.lastPracticeDate.isBlank()) return 0
        return try {
            val gap = ChronoUnit.DAYS.between(LocalDate.parse(s.lastPracticeDate), LocalDate.parse(day))
            if (gap <= 1L) s.streak else 0
        } catch (e: Exception) {
            0
        }
    }

    /** Catat satu latihan: streak, tanggal terakhir, total latihan. */
    fun registerPractice(s: ProgressState, day: String): ProgressState {
        val yesterday = LocalDate.parse(day).minusDays(1).toString()
        val newStreak = when (s.lastPracticeDate) {
            day -> maxOf(s.streak, 1)
            yesterday -> s.streak + 1
            else -> 1
        }
        return s.copy(
            streak = newStreak,
            lastPracticeDate = day,
            totalPractices = s.totalPractices + 1
        )
    }

    fun addTime(s: ProgressState, day: String, seconds: Int): ProgressState {
        val base = if (s.todayDate == day) s.todaySeconds else 0
        return s.copy(
            totalReadingSeconds = s.totalReadingSeconds + seconds,
            todayDate = day,
            todaySeconds = base + seconds
        )
    }

    fun todaySeconds(s: ProgressState, day: String = todayKey()): Int =
        if (s.todayDate == day) s.todaySeconds else 0

    /** Rata-rata WPM dari semua sesi; null jika belum ada data. */
    fun averageWpm(s: ProgressState): Int? {
        val valid = s.sessions.filter { it.words > 0 && it.seconds > 0 }
        if (valid.isEmpty()) return null
        val words = valid.sumOf { it.words }
        val secs = valid.sumOf { it.seconds }
        return (words * 60f / secs).roundToInt()
    }

    /** Akurasi jawaban (persen); null jika belum menjawab. */
    fun accuracy(s: ProgressState): Int? {
        val total = s.correctAnswers + s.wrongAnswers
        if (total == 0) return null
        return (s.correctAnswers * 100f / total).roundToInt()
    }

    /** WPM rata-rata per hari (maksimal 7 hari terakhir). */
    fun wpmByDay(s: ProgressState): List<Pair<String, Int>> =
        s.sessions
            .filter { it.words > 0 && it.seconds > 0 }
            .groupBy { it.date }
            .map { (d, list) ->
                d to (list.sumOf { it.words } * 60f / list.sumOf { it.seconds }).roundToInt()
            }
            .sortedBy { it.first }
            .takeLast(7)

    fun formatDuration(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        return when {
            h > 0 -> "$h jam $m menit"
            m > 0 -> "$m menit"
            else -> "$totalSeconds detik"
        }
    }

    fun formatClock(seconds: Int): String =
        "%02d:%02d".format(seconds / 60, seconds % 60)
}
