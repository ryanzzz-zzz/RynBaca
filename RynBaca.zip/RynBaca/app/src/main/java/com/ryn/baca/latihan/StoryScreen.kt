package com.ryn.baca.latihan

import android.os.SystemClock
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.MainViewModel
import com.ryn.baca.config.GameConfig
import com.ryn.baca.data.ContentRepository
import com.ryn.baca.model.Difficulty
import com.ryn.baca.model.Story
import com.ryn.baca.model.countWords
import com.ryn.baca.progress.ProgressCalc
import com.ryn.baca.ui.components.AnimatedProgressBar
import com.ryn.baca.ui.components.BigButton
import com.ryn.baca.ui.components.Pill
import com.ryn.baca.ui.components.RoundSummary
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.components.ScreenHeader
import com.ryn.baca.ui.components.SoftButton
import com.ryn.baca.ui.components.rememberElapsedSeconds
import com.ryn.baca.ui.theme.RynColors
import kotlin.math.roundToInt

private enum class StoryPhase { INTRO, READING, QUESTIONS, RESULT }

@Composable
fun StoryScreen(vm: MainViewModel, onExit: () -> Unit) {
    var selected by remember { mutableStateOf<Story?>(null) }
    val story = selected
    if (story == null) {
        StoryList(vm, onExit) { selected = it }
    } else {
        StoryReader(vm, story, onBackToList = { selected = null }, onExit = onExit)
    }
}

@Composable
private fun StoryList(vm: MainViewModel, onExit: () -> Unit, onPick: (Story) -> Unit) {
    val done = vm.progress.state.completedStories
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Cerita Pendek", onExit)
        Text("Pilih satu cerita untuk dibaca.", fontSize = 15.sp, color = RynColors.TextMuted)
        ContentRepository.stories.forEach { story ->
            RynCard(Modifier.fillMaxWidth(), onClick = { onPick(story) }) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(story.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (story.id in done) Pill("✓ Selesai", RynColors.SuccessLight, RynColors.Success)
                }
                Text(
                    "${story.difficulty.emoji} ${story.difficulty.label} • ${countWords(story.content)} kata",
                    fontSize = 13.sp,
                    color = RynColors.TextMuted
                )
            }
        }
    }
}

@Composable
private fun StoryReader(vm: MainViewModel, story: Story, onBackToList: () -> Unit, onExit: () -> Unit) {
    val context = LocalContext.current
    var phase by remember { mutableStateOf(StoryPhase.INTRO) }
    var startMs by remember { mutableLongStateOf(0L) }
    var readSeconds by remember { mutableIntStateOf(1) }
    var qIndex by remember { mutableIntStateOf(0) }
    var wrongPicks by remember { mutableStateOf(setOf<Int>()) }
    var solved by remember { mutableStateOf(false) }
    var firstTry by remember { mutableStateOf(true) }
    var gotXp by remember { mutableStateOf(false) }
    var correctCount by remember { mutableIntStateOf(0) }
    var earnedXp by remember { mutableIntStateOf(0) }
    val elapsed = rememberElapsedSeconds(phase == StoryPhase.READING, startMs)

    if (phase == StoryPhase.RESULT) {
        val wpm = (countWords(story.content) * 60f / readSeconds).roundToInt()
        RoundSummary(
            title = "Hebat!",
            message = "Kamu menjawab benar $correctCount dari ${story.questions.size} pertanyaan.\n" +
                "Perkiraan kecepatan bacamu: $wpm kata per menit.",
            xp = earnedXp,
            onAgain = onBackToList,
            onExit = onExit,
            againText = "Baca Cerita Lain"
        )
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader(story.title, onBackToList)

        when (phase) {
            StoryPhase.INTRO -> {
                RynCard(Modifier.fillMaxWidth()) {
                    Text("Siap membaca? 📖", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Tekan Mulai Membaca, lalu baca ceritanya dengan tenang. " +
                            "Setelah itu ada beberapa pertanyaan.",
                        fontSize = 16.sp,
                        color = RynColors.TextMuted
                    )
                }
                BigButton(
                    "⏱️ Mulai Membaca",
                    {
                        startMs = SystemClock.elapsedRealtime()
                        phase = StoryPhase.READING
                    },
                    Modifier.fillMaxWidth()
                )
            }

            StoryPhase.READING -> {
                Text(
                    "⏱️ ${ProgressCalc.formatClock(elapsed)}",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = RynColors.Primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                RynCard(Modifier.fillMaxWidth()) {
                    Text(
                        story.content,
                        fontSize = 21.sp,
                        lineHeight = 34.sp,
                        color = RynColors.TextDark
                    )
                }
                SoftButton("🔊 Dengarkan", { vm.speaker.speakOrNotify(context, story.content) }, Modifier.fillMaxWidth())
                BigButton(
                    "Selesai Membaca ✓",
                    {
                        readSeconds = ((SystemClock.elapsedRealtime() - startMs) / 1000).toInt().coerceAtLeast(1)
                        phase = StoryPhase.QUESTIONS
                    },
                    Modifier.fillMaxWidth(),
                    RynColors.Success
                )
            }

            StoryPhase.QUESTIONS -> {
                val q = story.questions[qIndex]
                val isLast = qIndex == story.questions.size - 1
                Text(
                    "Pertanyaan ${qIndex + 1} dari ${story.questions.size}",
                    fontSize = 14.sp,
                    color = RynColors.TextMuted
                )
                AnimatedProgressBar(qIndex.toFloat() / story.questions.size)
                Text(q.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RynColors.TextDark)

                q.options.forEachIndexed { idx, option ->
                    val isWrong = idx in wrongPicks
                    val isRight = solved && idx == q.answerIndex
                    val container = when {
                        isRight -> RynColors.SuccessLight
                        isWrong -> RynColors.DangerLight
                        else -> RynColors.Card
                    }
                    val border = when {
                        isRight -> RynColors.Success
                        isWrong -> RynColors.Danger
                        else -> RynColors.Track
                    }
                    OutlinedButton(
                        onClick = {
                            if (idx == q.answerIndex) {
                                solved = true
                                if (firstTry) {
                                    val r = vm.progress.recordAnswer(true)
                                    correctCount += 1
                                    earnedXp += r.xp
                                    gotXp = true
                                }
                            } else {
                                wrongPicks = wrongPicks + idx
                                if (firstTry) {
                                    vm.progress.recordAnswer(false)
                                    firstTry = false
                                }
                            }
                        },
                        enabled = !solved && !isWrong,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(2.dp, border),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = container,
                            disabledContainerColor = container,
                            contentColor = RynColors.TextDark,
                            disabledContentColor = RynColors.TextDark
                        )
                    ) {
                        Text(
                            "${"ABCD"[idx]}. $option",
                            fontSize = 18.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )
                    }
                }

                if (solved) {
                    Text(
                        if (gotXp) "Benar! 🎉\n+${GameConfig.XP_CORRECT_ANSWER} XP" else "Benar! 🎉",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = RynColors.Success,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                    BigButton(
                        if (isLast) "Selesai" else "Berikutnya",
                        {
                            if (!isLast) {
                                qIndex += 1
                                wrongPicks = emptySet()
                                solved = false
                                firstTry = true
                                gotXp = false
                            } else {
                                val r = vm.progress.recordStory(story, readSeconds)
                                earnedXp += r.xp
                                phase = StoryPhase.RESULT
                            }
                        },
                        Modifier.fillMaxWidth(),
                        RynColors.Success
                    )
                } else if (wrongPicks.isNotEmpty()) {
                    Text(
                        "Belum tepat 😊\nCoba lagi!",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = RynColors.Danger,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }
            }

            StoryPhase.RESULT -> Unit
        }
    }
}
