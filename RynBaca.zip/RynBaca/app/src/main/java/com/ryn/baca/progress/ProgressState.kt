package com.ryn.baca.progress

import kotlin.math.roundToInt

/** Catatan satu sesi membaca (kalimat atau cerita). */
data class SessionRecord(
    val date: String,      // yyyy-MM-dd (tanggal lokal perangkat)
    val type: String,      // "kalimat" atau "cerita"
    val words: Int,
    val seconds: Int
) {
    val wpm: Int get() = (words * 60f / seconds.coerceAtLeast(1)).roundToInt()
}

/** Semua data kemajuan anak. Disimpan lokal di perangkat. */
data class ProgressState(
    val childName: String = "",
    val xp: Int = 0,
    val streak: Int = 0,
    val lastPracticeDate: String = "",
    val totalPractices: Int = 0,
    val totalReadingSeconds: Long = 0L,
    val wordsDone: Int = 0,
    val syllablesDone: Int = 0,
    val sentencesDone: Int = 0,
    val completedStories: Set<String> = emptySet(),
    val correctAnswers: Int = 0,
    val wrongAnswers: Int = 0,
    val achievements: Set<String> = emptySet(),
    val hardWords: Map<String, Int> = emptyMap(),
    val sessions: List<SessionRecord> = emptyList(),
    val todayDate: String = "",
    val todaySeconds: Int = 0,
    val dailyBonusDate: String = ""
)

data class Reward(val xp: Int, val dailyBonus: Boolean)
