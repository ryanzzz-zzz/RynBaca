package com.ryn.baca.data

import com.ryn.baca.model.Difficulty
import com.ryn.baca.model.Question
import com.ryn.baca.model.Story

/**
 * Daftar cerita pendek (urut dari mudah ke sulit).
 * Untuk menambah cerita, salin salah satu blok Story(...) lalu ubah isinya.
 * Setiap cerita harus punya id yang unik.
 */
object StoryData {

    fun build(): List<Story> = listOf(
        Story(
            id = "c01",
            title = "Budi dan Buku Baru",
            difficulty = Difficulty.MUDAH,
            content = "Budi mendapatkan sebuah buku baru dari ayahnya. " +
                "Buku itu berisi cerita tentang hewan. " +
                "Setiap malam Budi membaca beberapa halaman. " +
                "Lama-kelamaan Budi menjadi semakin suka membaca.",
            questions = listOf(
                Question("Siapa yang memberikan buku kepada Budi?", listOf("Ibu", "Ayah", "Kakak", "Guru"), 1),
                Question("Buku itu berisi cerita tentang apa?", listOf("Hewan", "Pesawat", "Makanan", "Olahraga"), 0)
            )
        ),
        Story(
            id = "c02",
            title = "Kucing di Atas Meja",
            difficulty = Difficulty.MUDAH,
            content = "Ani punya seekor kucing. Namanya Mimi. " +
                "Mimi suka tidur di atas meja. " +
                "Pagi ini Mimi tidak ada di meja. " +
                "Ani mencari Mimi di kamar. " +
                "Ternyata Mimi tidur di bawah kursi.",
            questions = listOf(
                Question("Siapa nama kucing Ani?", listOf("Momo", "Mimi", "Miki", "Nana"), 1),
                Question("Di mana Mimi ditemukan?", listOf("Di kamar mandi", "Di atas meja", "Di bawah kursi", "Di halaman"), 2)
            )
        ),
        Story(
            id = "c03",
            title = "Bermain Bola",
            difficulty = Difficulty.MUDAH,
            content = "Sore ini Dodi bermain bola di lapangan. " +
                "Teman-temannya sudah datang. " +
                "Mereka bermain dengan gembira. " +
                "Tiba-tiba hujan turun. " +
                "Semua berlari pulang. " +
                "Dodi berjanji akan bermain lagi besok.",
            questions = listOf(
                Question("Di mana Dodi bermain bola?", listOf("Di halaman rumah", "Di lapangan", "Di sekolah", "Di pantai"), 1),
                Question("Apa yang membuat mereka pulang?", listOf("Hujan turun", "Ibu memanggil", "Bola pecah", "Hari gelap"), 0)
            )
        ),
        Story(
            id = "c04",
            title = "Pergi ke Pasar",
            difficulty = Difficulty.SEDANG,
            content = "Setiap hari Minggu, Ibu pergi ke pasar bersama Rini. " +
                "Ibu membeli sayur, ikan, dan buah. " +
                "Rini membantu membawa keranjang kecil. " +
                "Di pasar banyak orang berjualan. " +
                "Pedagang buah memberi Rini sebuah jeruk. " +
                "Rini mengucapkan terima kasih.",
            questions = listOf(
                Question("Kapan Ibu pergi ke pasar?", listOf("Setiap hari Senin", "Setiap hari Sabtu", "Setiap hari Minggu", "Setiap hari Jumat"), 2),
                Question("Apa yang diberikan pedagang buah kepada Rini?", listOf("Apel", "Jeruk", "Mangga", "Pisang"), 1),
                Question("Apa yang dilakukan Rini setelah menerima buah itu?", listOf("Menangis", "Berlari pergi", "Mengucapkan terima kasih", "Membeli ikan"), 2)
            )
        ),
        Story(
            id = "c05",
            title = "Kebun Kakek",
            difficulty = Difficulty.SEDANG,
            content = "Kakek memiliki kebun kecil di belakang rumah. " +
                "Di kebun itu tumbuh cabai, tomat, dan terong. " +
                "Setiap pagi Kakek menyiram tanaman. " +
                "Cucunya, Sinta, sering membantu memetik sayuran yang sudah matang. " +
                "Sayuran itu dimasak Nenek menjadi makanan yang lezat. " +
                "Sinta senang karena sayurannya segar.",
            questions = listOf(
                Question("Apa yang dilakukan Kakek setiap pagi?", listOf("Memetik buah", "Menyiram tanaman", "Memasak", "Membaca koran"), 1),
                Question("Siapa yang memasak sayuran itu?", listOf("Ibu", "Sinta", "Nenek", "Kakek"), 2),
                Question("Mengapa Sinta senang?", listOf("Karena sayurannya segar", "Karena mendapat hadiah", "Karena libur sekolah", "Karena kebunnya besar"), 0)
            )
        ),
        Story(
            id = "c06",
            title = "Petugas Bendera",
            difficulty = Difficulty.SEDANG,
            content = "Hari Senin adalah hari upacara di sekolah. " +
                "Semua murid berbaris rapi di lapangan. " +
                "Rafi bertugas menjadi pembawa bendera. " +
                "Awalnya ia merasa gugup. " +
                "Namun ia berlatih dengan tekun bersama teman-temannya. " +
                "Akhirnya Rafi berhasil melaksanakan tugasnya dengan baik.",
            questions = listOf(
                Question("Apa tugas Rafi saat upacara?", listOf("Pemimpin upacara", "Pembaca doa", "Pembawa bendera", "Petugas kebersihan"), 2),
                Question("Bagaimana perasaan Rafi di awal?", listOf("Marah", "Gugup", "Bosan", "Sedih"), 1),
                Question("Mengapa Rafi berhasil?", listOf("Karena dibantu guru", "Karena berlatih dengan tekun", "Karena beruntung", "Karena upacaranya singkat"), 1)
            )
        ),
        Story(
            id = "c07",
            title = "Semut yang Rajin",
            difficulty = Difficulty.SEDANG,
            content = "Di bawah pohon besar, hidup sekelompok semut. " +
                "Mereka bekerja bersama mengumpulkan makanan. " +
                "Ada yang membawa remah roti, ada yang membawa biji-bijian. " +
                "Musim hujan akan segera tiba. " +
                "Semut-semut menyimpan makanan di dalam sarang. " +
                "Saat hujan turun, mereka tidak kelaparan.",
            questions = listOf(
                Question("Mengapa semut mengumpulkan makanan?", listOf("Karena ingin berpesta", "Karena musim hujan akan tiba", "Karena disuruh raja", "Karena bosan"), 1),
                Question("Di mana semut menyimpan makanan?", listOf("Di bawah batu", "Di atas pohon", "Di dalam sarang", "Di dalam air"), 2),
                Question("Bagaimana cara semut bekerja?", listOf("Sendiri-sendiri", "Bersama-sama", "Sambil tidur", "Hanya pada malam hari"), 1)
            )
        ),
        Story(
            id = "c08",
            title = "Sungai yang Bersih",
            difficulty = Difficulty.SULIT,
            content = "Di dekat desa Ayu ada sebuah sungai yang jernih. " +
                "Dahulu warga sering membuang sampah ke sungai itu. " +
                "Akibatnya, airnya menjadi kotor dan berbau. " +
                "Ikan-ikan pun mulai menghilang. " +
                "Kemudian warga bergotong royong membersihkan sungai setiap minggu. " +
                "Mereka juga membuat aturan agar tidak membuang sampah sembarangan. " +
                "Beberapa bulan kemudian, sungai itu kembali bersih dan ikan-ikan datang lagi.",
            questions = listOf(
                Question("Apa akibat warga membuang sampah ke sungai?", listOf("Air menjadi kotor dan berbau", "Sungai menjadi dalam", "Ikan bertambah banyak", "Air menjadi dingin"), 0),
                Question("Apa yang dilakukan warga untuk memperbaiki sungai?", listOf("Pindah ke kota", "Menutup sungai", "Bergotong royong membersihkan sungai", "Menunggu hujan"), 2),
                Question("Apa pesan dari cerita ini?", listOf("Kita harus menjaga kebersihan lingkungan", "Ikan harus ditangkap", "Sungai tidak penting", "Desa harus dipindahkan"), 0)
            )
        ),
        Story(
            id = "c09",
            title = "Perpustakaan Baru",
            difficulty = Difficulty.SULIT,
            content = "Sekolah Tania mendapat sebuah perpustakaan baru. " +
                "Ruangannya luas dan penuh dengan buku yang menarik. " +
                "Pak Guru berpesan agar setiap murid merawat buku dengan baik. " +
                "Tania meminjam buku tentang luar angkasa. " +
                "Ia membacanya selama satu minggu, lalu mengembalikannya tepat waktu. " +
                "Sejak itu, Tania bercita-cita menjadi seorang astronaut.",
            questions = listOf(
                Question("Buku apa yang dipinjam Tania?", listOf("Buku masakan", "Buku tentang luar angkasa", "Buku tentang hewan", "Buku dongeng"), 1),
                Question("Apa pesan Pak Guru kepada murid?", listOf("Membaca dengan cepat", "Membawa buku pulang", "Merawat buku dengan baik", "Tidak berisik"), 2),
                Question("Apa cita-cita Tania sekarang?", listOf("Guru", "Dokter", "Pilot", "Astronaut"), 3)
            )
        ),
        Story(
            id = "c10",
            title = "Jujur Itu Membanggakan",
            difficulty = Difficulty.SULIT,
            content = "Dimas sangat ingin menjadi juara dalam lomba cerdas cermat. " +
                "Saat ujian latihan, ia melihat kunci jawaban tergeletak di meja guru. " +
                "Dimas sempat tergoda untuk membukanya. " +
                "Namun ia teringat pesan ayahnya bahwa kejujuran lebih berharga daripada nilai bagus. " +
                "Ia pun menutup buku itu dan mengerjakan soal sendiri. " +
                "Walaupun tidak menjadi juara pertama, Dimas merasa bangga karena ia telah berlaku jujur.",
            questions = listOf(
                Question("Apa yang membuat Dimas tergoda?", listOf("Hadiah lomba", "Kunci jawaban di meja guru", "Ajakan temannya", "Buku catatan"), 1),
                Question("Apa yang diingat Dimas?", listOf("Pesan ayah tentang kejujuran", "Janji kepada guru", "Jadwal lomba", "Nama juara"), 0),
                Question("Mengapa Dimas merasa bangga?", listOf("Karena menjadi juara pertama", "Karena mendapat nilai tertinggi", "Karena telah berlaku jujur", "Karena dipuji semua orang"), 2)
            )
        )
    )
}
