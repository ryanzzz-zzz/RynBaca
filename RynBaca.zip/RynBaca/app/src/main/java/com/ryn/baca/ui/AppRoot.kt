package com.ryn.baca.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ryn.baca.MainViewModel
import com.ryn.baca.latihan.Latihan
import com.ryn.baca.latihan.SentencePracticeScreen
import com.ryn.baca.latihan.StoryScreen
import com.ryn.baca.latihan.SyllablePracticeScreen
import com.ryn.baca.latihan.WordPracticeScreen
import com.ryn.baca.ui.components.AchievementDialog
import com.ryn.baca.ui.theme.RynColors

enum class Tab(val label: String, val emoji: String) {
    BERANDA("Beranda", "🏠"),
    BELAJAR("Belajar", "📖"),
    PROGRESS("Progress", "📈"),
    PROFIL("Profil", "👤")
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(Tab.BERANDA) }
    var latihan by rememberSaveable { mutableStateOf<Latihan?>(null) }

    BackHandler(enabled = latihan != null) { latihan = null }

    Scaffold(
        containerColor = RynColors.Background,
        bottomBar = {
            if (latihan == null) {
                NavigationBar(containerColor = RynColors.Card) {
                    Tab.values().forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Text(t.emoji, fontSize = 22.sp) },
                            label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = RynColors.PrimaryLight)
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            Crossfade(targetState = Pair(latihan, tab), label = "page") { (current, currentTab) ->
                if (current != null) {
                    val exit = { latihan = null }
                    when (current) {
                        Latihan.KATA -> WordPracticeScreen(vm, exit)
                        Latihan.SUKU_KATA -> SyllablePracticeScreen(vm, exit)
                        Latihan.KALIMAT -> SentencePracticeScreen(vm, exit)
                        Latihan.CERITA -> StoryScreen(vm, exit)
                    }
                } else {
                    when (currentTab) {
                        Tab.BERANDA -> HomeScreen(
                            vm,
                            onStartLearning = { tab = Tab.BELAJAR },
                            onOpen = { latihan = it }
                        )
                        Tab.BELAJAR -> LearnMenuScreen(onOpen = { latihan = it })
                        Tab.PROGRESS -> ProgressScreen(vm)
                        Tab.PROFIL -> ProfileScreen(vm)
                    }
                }
            }
        }
    }

    val pending = vm.progress.pendingAchievements.firstOrNull()
    if (pending != null) {
        AchievementDialog(pending) { vm.progress.pendingAchievements.removeAt(0) }
    }
}
