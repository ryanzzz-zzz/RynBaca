package com.ryn.baca.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/**
 * Pembaca suara (Text-to-Speech Android) berbahasa Indonesia.
 * Jika suara tidak tersedia, aplikasi tetap berjalan normal.
 */
class Speaker(context: Context) {
    private var engine: TextToSpeech? = null

    var available by mutableStateOf(false)
        private set

    init {
        try {
            engine = TextToSpeech(context.applicationContext) { status -> onInit(status) }
        } catch (e: Exception) {
            available = false
        }
    }

    private fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val result = engine?.setLanguage(Locale("id", "ID")) ?: return
        available = result != TextToSpeech.LANG_MISSING_DATA &&
            result != TextToSpeech.LANG_NOT_SUPPORTED
        if (available) engine?.setSpeechRate(0.85f)
    }

    fun speak(text: String) {
        if (!available) return
        engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ryn_baca")
    }

    /** Bicara; jika suara tidak ada, tampilkan pesan ramah. */
    fun speakOrNotify(context: Context, text: String) {
        if (available) {
            speak(text)
        } else {
            Toast.makeText(
                context,
                "Suara belum tersedia di HP ini, tapi kamu tetap bisa berlatih 😊",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
    }
}
