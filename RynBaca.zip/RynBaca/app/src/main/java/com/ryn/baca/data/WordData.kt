package com.ryn.baca.data

import com.ryn.baca.model.Difficulty
import com.ryn.baca.model.Word

/**
 * Daftar kata. Format tiap baris:  kata|su-ku-ka-ta
 * Untuk menambah kata, cukup tambah baris baru di daftar yang sesuai.
 */
object WordData {

    private val EASY = """
aku|a-ku
ibu|i-bu
ayah|a-yah
buku|bu-ku
bola|bo-la
rumah|ru-mah
makan|ma-kan
minum|mi-num
sekolah|se-ko-lah
kakak|ka-kak
adik|a-dik
nenek|ne-nek
kakek|ka-kek
meja|me-ja
kursi|kur-si
pintu|pin-tu
jendela|jen-de-la
kucing|ku-cing
ayam|a-yam
ikan|i-kan
bunga|bu-nga
pohon|po-hon
air|a-ir
roti|ro-ti
nasi|na-si
susu|su-su
baju|ba-ju
sepatu|se-pa-tu
tas|tas
topi|to-pi
pagi|pa-gi
malam|ma-lam
hujan|hu-jan
angin|a-ngin
langit|la-ngit
tidur|ti-dur
duduk|du-duk
lari|la-ri
jalan|ja-lan
teman|te-man
guru|gu-ru
kamar|ka-mar
mobil|mo-bil
sapi|sa-pi
"""

    private val MEDIUM = """
bermain|ber-ma-in
membaca|mem-ba-ca
belajar|be-la-jar
berjalan|ber-ja-lan
matahari|ma-ta-ha-ri
kesehatan|ke-se-ha-tan
perjalanan|per-ja-la-nan
menulis|me-nu-lis
bernyanyi|ber-nya-nyi
berlari|ber-la-ri
makanan|ma-ka-nan
minuman|mi-nu-man
sayuran|sa-yu-ran
pelajaran|pe-la-ja-ran
pekerjaan|pe-ker-ja-an
keluarga|ke-lu-ar-ga
tetangga|te-tang-ga
pasar|pa-sar
kebun|ke-bun
sawah|sa-wah
sungai|su-ngai
gunung|gu-nung
pantai|pan-tai
burung|bu-rung
kelinci|ke-lin-ci
harimau|ha-ri-mau
gajah|ga-jah
sepeda|se-pe-da
komputer|kom-pu-ter
telepon|te-le-pon
lapangan|la-pa-ngan
bendera|ben-de-ra
upacara|u-pa-ca-ra
hadiah|ha-di-ah
gembira|gem-bi-ra
bahagia|ba-ha-gia
kesempatan|ke-sem-pa-tan
"""

    private val HARD = """
kebersihan|ke-ber-si-han
bertanggung jawab|ber-tang-gung ja-wab
persahabatan|per-sa-ha-ba-tan
lingkungan|ling-kung-an
perpustakaan|per-pus-ta-ka-an
pengetahuan|pe-nge-ta-hu-an
kemerdekaan|ke-mer-de-ka-an
pemandangan|pe-man-da-ngan
kesungguhan|ke-sung-guh-an
keberanian|ke-be-ra-ni-an
kejujuran|ke-ju-ju-ran
kedisiplinan|ke-di-si-pli-nan
penghargaan|peng-har-ga-an
kesabaran|ke-sa-ba-ran
pertandingan|per-tan-ding-an
pengalaman|pe-nga-la-man
percaya diri|per-ca-ya di-ri
berpengetahuan|ber-pe-nge-ta-hu-an
mempersiapkan|mem-per-si-ap-kan
memperhatikan|mem-per-ha-ti-kan
menyenangkan|me-nye-nang-kan
menyeberang|me-nye-be-rang
pertunjukan|per-tun-juk-an
kebahagiaan|ke-ba-ha-gi-a-an
perkembangan|per-kem-ba-ngan
berkelompok|ber-ke-lom-pok
mengerjakan|meng-er-ja-kan
bertetangga|ber-te-tang-ga
pemberani|pem-be-ra-ni
kesempurnaan|ke-sem-pur-na-an
pertemanan|per-te-man-an
"""

    private fun parse(raw: String, d: Difficulty, prefix: String): List<Word> =
        raw.lines().map { it.trim() }.filter { it.isNotEmpty() }.mapIndexed { i, line ->
            val parts = line.split("|")
            Word(
                id = "$prefix${i + 1}",
                word = parts[0],
                syllables = parts[1].split("-", " ").filter { it.isNotBlank() },
                difficulty = d
            )
        }

    fun build(): List<Word> =
        parse(EASY, Difficulty.MUDAH, "m") +
            parse(MEDIUM, Difficulty.SEDANG, "s") +
            parse(HARD, Difficulty.SULIT, "h")
}
