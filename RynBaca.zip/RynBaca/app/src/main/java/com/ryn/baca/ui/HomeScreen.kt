package com.ryn.baca.ui

import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ryn.baca.MainViewModel
import com.ryn.baca.config.GameConfig
import com.ryn.baca.latihan.Latihan
import com.ryn.baca.progress.ProgressCalc
import com.ryn.baca.ui.components.AnimatedProgressBar
import com.ryn.baca.ui.components.BigButton
import com.ryn.baca.ui.components.RynCard
import com.ryn.baca.ui.theme.RynColors

@Composable
fun HomeScreen(vm: MainViewModel, onStartLearning: () -> Unit, onOpen: (Latihan) -> Unit) {
    val s = vm.progress.state
    val day = ProgressCalc.todayKey()
    val level = GameConfig.levelForXp(s.xp)
    val inLevel = GameConfig.xpIntoLevel(s.xp)
    val streak = ProgressCalc.currentStreak(s, day)
    val todaySec = ProgressCalc.todaySeconds(s, day)
    val targetSec = GameConfig.DAILY_TARGET_MINUTES * 60
    val readingProgress = (todaySec.toFloat() / targetSec).coerceIn(0f, 1f)
    val shownXp by animateIntAsState(inLevel, tween(700), label = "xp")

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                if (s.childName.isBlank()) "Halo! 👋" else "Halo, ${s.childName}! 👋",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = RynColors.TextDark
            )
            Text(GameConfig.TAGLINE, fontSize = 14.sp, color = RynColors.TextMuted)
        }

        RynCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Level $level", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = RynColors.Primary)
                    Text("XP: $shownXp / ${GameConfig.XP_PER_LEVEL}", fontSize = 15.sp, color = RynColors.TextMuted)
                }
                Text("🔥 Streak: $streak hari", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(12.dp))
            AnimatedProgressBar(inLevel.toFloat() / GameConfig.XP_PER_LEVEL, color = RynColors.Accent)
        }

        RynCard(Modifier.fillMaxWidth()) {
            Text("Progress membaca", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedProgressBar(readingProgress, Modifier.weight(1f))
                Spacer(Modifier.width(12.dp))
                Text("${(readingProgress * 100).toInt()}%", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Target hari ini: ${GameConfig.DAILY_TARGET_MINUTES} menit membaca",
                fontSize = 14.sp,
                color = RynColors.TextMuted
            )
            Text(
                "Sudah membaca: ${ProgressCalc.formatDuration(todaySec.toLong())}",
                fontSize = 14.sp,
                color = RynColors.TextMuted
            )
        }

        BigButton("MULAI BELAJAR", onStartLearning, Modifier.fillMaxWidth())

        Text("Latihan Hari Ini", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = RynColors.TextDark)
        TodayItem("🔤", "Latihan Kata", "+${GameConfig.XP_WORD} XP tiap kata") { onOpen(Latihan.KATA) }
        TodayItem("📖", "Latihan Kalimat", "+${GameConfig.XP_SENTENCE} XP tiap kalimat") { onOpen(Latihan.KALIMAT) }
        TodayItem("📚", "Cerita Pendek", "+${GameConfig.XP_STORY} XP tiap cerita") { onOpen(Latihan.CERITA) }
    }
}

@Composable
private fun TodayItem(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    RynCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, fontSize = 13.sp, color = RynColors.TextMuted)
            }
        }
    }
}
