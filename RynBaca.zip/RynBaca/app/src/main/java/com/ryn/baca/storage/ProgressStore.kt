package com.ryn.baca.storage

import android.content.Context
import com.ryn.baca.progress.ProgressState
import com.ryn.baca.progress.SessionRecord
import org.json.JSONArray
import org.json.JSONObject

/** Menyimpan progress di HP (SharedPreferences). Tidak butuh internet. */
class ProgressStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("ryn_baca_progress", Context.MODE_PRIVATE)

    fun load(): ProgressState {
        val raw = prefs.getString(KEY, null) ?: return ProgressState()
        return try {
            ProgressJson.fromJson(JSONObject(raw))
        } catch (e: Exception) {
            ProgressState()
        }
    }

    fun save(state: ProgressState) {
        prefs.edit().putString(KEY, ProgressJson.toJson(state).toString()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "state_v1"
    }
}

object ProgressJson {
    fun toJson(s: ProgressState): JSONObject {
        val o = JSONObject()
        o.put("childName", s.childName)
        o.put("xp", s.xp)
        o.put("streak", s.streak)
        o.put("lastPracticeDate", s.lastPracticeDate)
        o.put("totalPractices", s.totalPractices)
        o.put("totalReadingSeconds", s.totalReadingSeconds)
        o.put("wordsDone", s.wordsDone)
        o.put("syllablesDone", s.syllablesDone)
        o.put("sentencesDone", s.sentencesDone)
        o.put("correctAnswers", s.correctAnswers)
        o.put("wrongAnswers", s.wrongAnswers)
        o.put("todayDate", s.todayDate)
        o.put("todaySeconds", s.todaySeconds)
        o.put("dailyBonusDate", s.dailyBonusDate)
        o.put("completedStories", JSONArray(s.completedStories.toList()))
        o.put("achievements", JSONArray(s.achievements.toList()))
        val hard = JSONObject()
        s.hardWords.forEach { (k, v) -> hard.put(k, v) }
        o.put("hardWords", hard)
        val arr = JSONArray()
        s.sessions.forEach {
            val x = JSONObject()
            x.put("date", it.date)
            x.put("type", it.type)
            x.put("words", it.words)
            x.put("seconds", it.seconds)
            arr.put(x)
        }
        o.put("sessions", arr)
        return o
    }

    fun fromJson(o: JSONObject): ProgressState {
        fun strings(key: String): Set<String> {
            val a = o.optJSONArray(key) ?: return emptySet()
            return (0 until a.length()).map { a.getString(it) }.toSet()
        }

        val hard = mutableMapOf<String, Int>()
        val h = o.optJSONObject("hardWords")
        if (h != null) {
            val keys = h.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                hard[k] = h.getInt(k)
            }
        }

        val sessions = mutableListOf<SessionRecord>()
        val a = o.optJSONArray("sessions")
        if (a != null) {
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                sessions.add(
                    SessionRecord(
                        date = x.getString("date"),
                        type = x.optString("type", "kalimat"),
                        words = x.getInt("words"),
                        seconds = x.getInt("seconds")
                    )
                )
            }
        }

        return ProgressState(
            childName = o.optString("childName", ""),
            xp = o.optInt("xp", 0),
            streak = o.optInt("streak", 0),
            lastPracticeDate = o.optString("lastPracticeDate", ""),
            totalPractices = o.optInt("totalPractices", 0),
            totalReadingSeconds = o.optLong("totalReadingSeconds", 0L),
            wordsDone = o.optInt("wordsDone", 0),
            syllablesDone = o.optInt("syllablesDone", 0),
            sentencesDone = o.optInt("sentencesDone", 0),
            completedStories = strings("completedStories"),
            correctAnswers = o.optInt("correctAnswers", 0),
            wrongAnswers = o.optInt("wrongAnswers", 0),
            achievements = strings("achievements"),
            hardWords = hard,
            sessions = sessions,
            todayDate = o.optString("todayDate", ""),
            todaySeconds = o.optInt("todaySeconds", 0),
            dailyBonusDate = o.optString("dailyBonusDate", "")
        )
    }
}
