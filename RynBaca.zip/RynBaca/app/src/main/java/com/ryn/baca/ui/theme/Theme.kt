package com.ryn.baca.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Semua warna aplikasi ada di sini. Ubah nilai warna untuk mengganti tampilan. */
object RynColors {
    val Primary = Color(0xFF3B5BDB)
    val PrimaryLight = Color(0xFFE7ECFF)
    val Accent = Color(0xFFFF922B)
    val AccentLight = Color(0xFFFFF0DD)
    val Success = Color(0xFF2F9E62)
    val SuccessLight = Color(0xFFE3F6EB)
    val Warning = Color(0xFFF08C00)
    val Danger = Color(0xFFE8590C)
    val DangerLight = Color(0xFFFFEBDD)
    val Background = Color(0xFFF4F6FB)
    val Card = Color.White
    val TextDark = Color(0xFF1F2547)
    val TextMuted = Color(0xFF6B7392)
    val Track = Color(0xFFE3E7F3)
}

@Composable
fun RynBacaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = RynColors.Primary,
            onPrimary = Color.White,
            secondary = RynColors.Accent,
            background = RynColors.Background,
            surface = RynColors.Card,
            onBackground = RynColors.TextDark,
            onSurface = RynColors.TextDark,
            primaryContainer = RynColors.PrimaryLight,
            surfaceVariant = RynColors.Track
        ),
        content = content
    )
}
