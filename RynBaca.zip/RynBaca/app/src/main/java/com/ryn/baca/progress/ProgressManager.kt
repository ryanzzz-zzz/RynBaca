package com.ryn.baca.progress

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ryn.baca.achievement.Achievement
import com.ryn.baca.achievement.Achievements
import com.ryn.baca.config.GameConfig
import com.ryn.baca.model.Sentence
import com.ryn.baca.model.Story
import com.ryn.baca.model.Word
import com.ryn.baca.model.WordRating
import com.ryn.baca.model.countWords
import com.ryn.baca.storage.ProgressStore

/** Otak pencatat progress: XP, streak, waktu, pencapaian. Setiap perubahan langsung disimpan. */
class ProgressManager(private val store: ProgressStore) {

    var state by mutableStateOf(store.load())
        private set

    /** Pencapaian baru yang menunggu ditampilkan. */
    val pendingAchievements = mutableStateListOf<Achievement>()

    private fun finish(s: ProgressState, day: String, baseXp: Int): Reward {
        var next = s
        var gained = baseXp
        var bonus = false
        val targetSeconds = GameConfig.DAILY_TARGET_MINUTES * 60
        if (ProgressCalc.todaySeconds(next, day) >= targetSeconds && next.dailyBonusDate != day) {
            next = next.copy(
                dailyBonusDate = day,
                xp = next.xp + GameConfig.XP_DAILY_TARGET
            )
            gained += GameConfig.XP_DAILY_TARGET
            bonus = true
        }
        val unlocked = Achievements.newlyUnlocked(next)
        if (unlocked.isNotEmpty()) {
            next = next.copy(achievements = next.achievements + unlocked.map { it.id })
            pendingAchievements.addAll(unlocked)
        }
        state = next
        store.save(next)
        return Reward(gained, bonus)
    }

    fun recordWord(word: Word, rating: WordRating, seconds: Int): Reward {
        val day = ProgressCalc.todayKey()
        var s = ProgressCalc.registerPractice(state, day)
        s = ProgressCalc.addTime(s, day, seconds.coerceIn(1, GameConfig.MAX_WORD_SECONDS))
        val hard = if (rating == WordRating.SULIT) {
            s.hardWords + (word.word to ((s.hardWords[word.word] ?: 0) + 1))
        } else {
            s.hardWords
        }
        s = s.copy(
            wordsDone = s.wordsDone + 1,
            hardWords = hard,
            xp = s.xp + GameConfig.XP_WORD
        )
        return finish(s, day, GameConfig.XP_WORD)
    }

    fun recordSyllable(seconds: Int): Reward {
        val day = ProgressCalc.todayKey()
        var s = ProgressCalc.registerPractice(state, day)
        s = ProgressCalc.addTime(s, day, seconds.coerceIn(1, GameConfig.MAX_WORD_SECONDS))
        s = s.copy(
            syllablesDone = s.syllablesDone + 1,
            xp = s.xp + GameConfig.XP_SYLLABLE
        )
        return finish(s, day, GameConfig.XP_SYLLABLE)
    }

    fun recordSentence(sentence: Sentence, seconds: Int): Reward {
        val day = ProgressCalc.todayKey()
        val secs = seconds.coerceAtLeast(1)
        var s = ProgressCalc.registerPractice(state, day)
        s = ProgressCalc.addTime(s, day, secs)
        val record = SessionRecord(day, "kalimat", countWords(sentence.text), secs)
        s = s.copy(
            sentencesDone = s.sentencesDone + 1,
            sessions = (s.sessions + record).takeLast(300),
            xp = s.xp + GameConfig.XP_SENTENCE
        )
        return finish(s, day, GameConfig.XP_SENTENCE)
    }

    fun recordStory(story: Story, seconds: Int): Reward {
        val day = ProgressCalc.todayKey()
        val secs = seconds.coerceAtLeast(1)
        var s = ProgressCalc.registerPractice(state, day)
        s = ProgressCalc.addTime(s, day, secs)
        val record = SessionRecord(day, "cerita", countWords(story.content), secs)
        s = s.copy(
            completedStories = s.completedStories + story.id,
            sessions = (s.sessions + record).takeLast(300),
            xp = s.xp + GameConfig.XP_STORY
        )
        return finish(s, day, GameConfig.XP_STORY)
    }

    /** Dipanggil saat anak menjawab pertanyaan (hanya percobaan pertama yang dihitung). */
    fun recordAnswer(correct: Boolean): Reward {
        val s = if (correct) {
            state.copy(
                correctAnswers = state.correctAnswers + 1,
                xp = state.xp + GameConfig.XP_CORRECT_ANSWER
            )
        } else {
            state.copy(wrongAnswers = state.wrongAnswers + 1)
        }
        return finish(s, ProgressCalc.todayKey(), if (correct) GameConfig.XP_CORRECT_ANSWER else 0)
    }

    fun setName(name: String) {
        val next = state.copy(childName = name.take(20))
        state = next
        store.save(next)
    }

    fun resetAll() {
        store.clear()
        state = ProgressState()
        pendingAchievements.clear()
    }
}
